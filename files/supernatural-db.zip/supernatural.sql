-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2020 at 10:24 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supernatural`
--

-- --------------------------------------------------------

--
-- Table structure for table `workouts`
--

CREATE TABLE `workouts` (
  `workout_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `accuracy` int(11) NOT NULL,
  `power` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `workouts`
--

INSERT INTO `workouts` (`workout_id`, `name`, `accuracy`, `power`) VALUES
(1, 'Aisha', 71, 92),
(2, 'Andreas', 86, 79),
(3, 'August', 74, 82),
(4, 'Bertha', 92, 95),
(5, 'Bessie', 99, 77),
(6, 'Boyd', 75, 75),
(7, 'Bridgette', 73, 78),
(8, 'Carrie', 90, 83),
(9, 'Carter', 88, 75),
(10, 'Cassandra', 84, 98),
(11, 'Catherine', 98, 93),
(12, 'Corine', 70, 87),
(13, 'Danial', 97, 79),
(14, 'Darell', 86, 89),
(15, 'Dawn', 75, 90),
(16, 'Deborah', 92, 72),
(17, 'Dewey', 100, 94),
(18, 'Elvira', 81, 100),
(19, 'Flossie', 95, 94),
(20, 'Foster', 78, 75),
(21, 'Georgia', 89, 96),
(22, 'Gerald', 97, 75),
(23, 'Glenda', 95, 75),
(24, 'Heather', 70, 71),
(25, 'Herman', 71, 95),
(26, 'Isabella', 73, 76),
(27, 'Johnnie', 91, 84),
(28, 'Jonas', 85, 96),
(29, 'Josh', 87, 86),
(30, 'Juan', 85, 73),
(31, 'Leticia', 85, 100),
(32, 'Lino', 85, 74),
(33, 'Long', 87, 85),
(34, 'Lydia', 70, 74),
(35, 'Major', 85, 94),
(36, 'Manuela', 96, 99),
(37, 'Marcus', 88, 86),
(38, 'Mike', 75, 93),
(39, 'Morton', 90, 83),
(40, 'Pauline', 76, 83),
(41, 'Rebekah', 76, 90),
(42, 'Rhonda', 80, 91),
(43, 'Rodolfo', 99, 70),
(44, 'Rory', 81, 80),
(45, 'Sarah', 94, 97),
(46, 'Stefanie', 86, 95),
(47, 'Stewart', 71, 88),
(48, 'Vincent', 74, 79),
(49, 'Wanda', 76, 77),
(50, 'Wilfred', 70, 73);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `workouts`
--
ALTER TABLE `workouts`
  ADD PRIMARY KEY (`workout_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `workouts`
--
ALTER TABLE `workouts`
  MODIFY `workout_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
